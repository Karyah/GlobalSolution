package br.com.fiap.enums;

public enum EnumTamanho {
	Kids, Adulto;
}
