insert into Usuario (login, nome, email, senha) values('kaka12','Karen Antiqueira','karenantique@gmail.com','kkkaren241');

insert into Usuario (login, nome, email, senha) values('akko','Davi Silva Souza','silvaSouza@yahoo.com.br','po8912rta');

insert into Usuario (login, nome, email, senha) values('luffy','Carlos Ant�nio','dluffycarlos@bol.com','onepice987');

insert into Usuario (login, nome, email, senha) values('vanesSA','Vanessa Laranjeiras','vanvan@gmail.com','Chocolate1.');

insert into Usuario (login, nome, email, senha) values('Megumi','Karina Megumi Sakamoto','karimegumi@gmail.com','MEgumiii');

insert into Usuario (login, nome, email, senha) values('Fina','Josefina Matos','matosjosefina@yahoo.com','12042008J.');
    
insert into Usuario (login, nome, email, senha) values('mariahhh','Maria Jos�','marijose@gmail.com','judelsoi123');

insert into Usuario (login, nome, email, senha) values('Carlinha','Carla Barros Borges','ACarlinha@outlook.com','odeioBarros12');

insert into Usuario (login, nome, email, senha) values('OCardoso','Pedro Cardoso Campos','cardoso@gmail.com','ped342cardoss');

insert into Usuario (login, nome, email, senha) values('Fernandas2','Fernanda Freitas Fernandas','FFFernanda@yahoo.com.br','fefrefe123');

insert into Ponto (endereco, idUsuario) values('Rua Machado de Assis 137',10);

insert into Ponto (endereco, idUsuario) values('Avenida Paulista, 900',4);

insert into Ponto (endereco, idUsuario) values('Castelo Branco, 1080',5);

insert into Ponto (endereco, idUsuario) values('Rua dos Imigrantes, n�mero 25',6);

insert into Ponto (endereco, idUsuario) values('Rua S�o Jo�o, 87',7);

insert into Ponto (endereco, idUsuario) values('Rua Quinze de Novembro, Centro. Em frente ao n�mero 140.',8);

insert into Ponto (endereco, idUsuario) values('Rua Tiradentes, n� 307',9);

insert into Ponto (endereco, idUsuario) values('Rua General Roberto Alves de Carvalho Filho, 241. Perto do hospital.',3);

insert into Ponto (endereco, idUsuario) values('Rua Tarsila do Amaral, 100',2);

insert into Ponto (endereco, idUsuario) values('Rua Jos� Paulino, n� 307.',1);

insert into Bicicleta (serial, tamanho, disponibilidade) values ('AC7008896','Kids', 'Dispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('BZO90123','Adulto', 'Indispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('ZDA983214','Adulto', 'Indispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('KHL0098392','Adulto', 'Dispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('POL8923470','Kids', 'Dispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('JJD2384510','Adulto', 'Dispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('AAV001213','Kids', 'Indispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('CD998012','Adulto', 'Dispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('BER7324657','Kids', 'Dispon�vel');

insert into Bicicleta (serial, tamanho, disponibilidade) values ('OOL988650','Adulto', 'Indispon�vel');

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('1','6',50);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('8','3',90);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('5','2',110);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('2','5',120);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('3','4',40);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('4','3',180);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('9','9',160);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('7','10',60);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('8','3',150);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('6','1',130);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('2','7',103);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('7','9',240);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('5','6',145);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('10','1',50);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('8','7',230);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('2','10',85);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('7','4',180);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('5','5',130);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('9','10',80);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('2','2',100);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('10','8',75);

insert into Aluguel(idUsuario, idBicicleta, tempoDeUso) values('3','9',80);
